Use readNexFile function to read the contents of *.nex file in Matlab.
For example:

nexFileData = readNexFile(filePath);


nexFileData is a structure that contains all the data from .nex file.

See comments in the readNexFile.m file for more info.
